package entities;

public class SetUpTower {

}
