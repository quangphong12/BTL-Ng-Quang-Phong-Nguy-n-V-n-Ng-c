import ultil.TowerFrame;

public class Main {
    public static void main(String[] args) {
        TowerFrame towerFrame = new TowerFrame();
        towerFrame.setVisible(true);
    }
}
